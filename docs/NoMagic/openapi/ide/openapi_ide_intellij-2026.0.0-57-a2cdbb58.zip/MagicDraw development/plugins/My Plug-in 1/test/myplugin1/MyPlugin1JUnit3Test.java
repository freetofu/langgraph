package myplugin1;

import com.nomagic.magicdraw.tests.MagicDrawTestCase;

/**
 * Simple plugin initialization test using JUnit3 framework.
 * It is recommended to write tests using JUnit5, please see {@link MyPlugin1JUnit5Test}
 */
public class MyPlugin1JUnit3Test extends MagicDrawTestCase{

	public void testPluginInitialized() {
		assertTrue(MyPlugin1.initialized);
	}
}
